
import java.util.Scanner;


public class Main {

    static Scanner in=new Scanner(System.in);
    public static void main(String[] args) {
        System.out.println("***WELCOME***\n\n___a am Ali Khodsiyani___\n\n___tel ID: alikh718");
        boolean flag=true;
        while(flag){
        BigInt a = new BigInt();
        BigInt b = new BigInt();        
        BigInt c = new BigInt();

        System.out.println("enter number 1: ");
       
        a.setNumber(in.nextLine());
        
        System.out.println("enter operator(+,-,/,*,%,^): ");
        String op=in.nextLine();
        System.out.println("enter number 2: ");
        b.setNumber(in.nextLine());
        
        if(op.charAt(0)=='+')
            c.setSum(a, b);
        else if(op.charAt(0)=='-')
            c.setSubstraction(a, b);
        else if(op.charAt(0)=='*')
            c.setMultiplication(a, b);
        else if(op.charAt(0)=='/')
            c.setDivision(a, b);
        else if(op.charAt(0)=='%')
            c.setMod(a, b);
        else if(op.charAt(0)=='^')
            c.pow(a, b);
       
        
        System.out.println(c.toString());
        System.out.println("edame midahid???(y or n) ");
        String g=in.nextLine();
        if(g.charAt(0)=='n' || g.charAt(0)=='N') {
            flag=false;
        } 
        }
        
    }
}
