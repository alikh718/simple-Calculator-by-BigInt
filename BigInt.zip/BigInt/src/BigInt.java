
import java.math.*;
import java.math.BigInteger;

public class BigInt {
    private String Number;

    //################CONSTRACTORS################
    public BigInt() 
    {
        Number="";
    }
     public BigInt(String Number) 
    {
        this.Number=Number;
    }

    //################GETTER################
    public String getNumber() {
        return Number;
    }    
    //################SETTER################
    public void setNumber(String Number) {
        this.Number = Number;
    }

    //################TO STRING################
    @Override    
    public String toString() {
        return "result= "+this.getNumber();
    }

    //################MATH FUNCTIONS################
    //!!!!!!!!!!!!!!!!FOR SUM!!!!!!!!!!!!!!!!!!!!!!!
    public void setSum(String p1, String p2) {
        p1=changeToGood(p1);
        p2=changeToGood(p2);
        
        BigInteger obj1=new BigInteger(p1);
        BigInteger obj2=new BigInteger(p2);
        BigInteger setSum;
        setSum=obj1.add(obj2);
        this.Number=setSum.toString();
    }
    
    void setSum(BigInt a, BigInt b) {
        setSum(a.getNumber(),b.getNumber());
    }//END SUM
    
    //!!!!!!!!!!!!!!!!FOR setSubstraction!!!!!!!!!!!!!!!!!!!!!!!
    public void setSubstraction(String p1, String p2) {
        p1=changeToGood(p1);
        p2=changeToGood(p2);
        
        BigInteger obj1=new BigInteger(p1);
        BigInteger obj2=new BigInteger(p2);
        BigInteger setSubstraction;
        setSubstraction=obj1.subtract(obj2);
        this.Number=setSubstraction.toString();   
    }
    void setSubstraction(BigInt a, BigInt b) {
        setSubstraction(a.getNumber(),b.getNumber());
    }//END setSubtraction


    //!!!!!!!!!!!!!!!!FOR setMultiplication!!!!!!!!!!!!!!!!!!!!!!!
    public void setMultiplication(String p1, String p2) {
        p1=changeToGood(p1);
        p2=changeToGood(p2);
        
        BigInteger obj1=new BigInteger(p1);
        BigInteger obj2=new BigInteger(p2);
        BigInteger setMultiplication;
        setMultiplication=obj1.multiply(obj2);
        this.Number=setMultiplication.toString();   
    }
    void setMultiplication(BigInt a, BigInt b) {
        setMultiplication(a.getNumber(),b.getNumber());
    }//END setMultiplication


    //!!!!!!!!!!!!!!!!FOR setDivision!!!!!!!!!!!!!!!!!!!!!!!
    public void setDivision(String p1, String p2) {
        p1=changeToGood(p1);
        p2=changeToGood(p2);
        
        BigInteger obj1=new BigInteger(p1);
        BigInteger obj2=new BigInteger(p2);
        BigInteger setDivision;
        setDivision=obj1.divide(obj2);
        this.Number=setDivision.toString();   
    }
    void setDivision(BigInt a, BigInt b) {
        setDivision(a.getNumber(),b.getNumber());
    }//END setDivision


    //!!!!!!!!!!!!!!!!FOR setMod!!!!!!!!!!!!!!!!!!!!!!!
    public void setMod(String p1, String p2) {
        p1=changeToGood(p1);
        p2=changeToGood(p2);
        
        BigInteger obj1=new BigInteger(p1);
        BigInteger obj2=new BigInteger(p2);
        BigInteger setMod;
        setMod=obj1.mod(obj2);
        this.Number=setMod.toString();   
    }
    void setMod(BigInt a, BigInt b) {
        setMod(a.getNumber(),b.getNumber());
    }//END setMod

    //FOR DELET CHARACTERS AND... FROM STRING
    private String changeToGood(String s) {
        String s2="";
        int start=0;
        
        if(s.charAt(0)=='+' || s.charAt(0)=='-')
        {
            s2=s.charAt(0)+"";
            start=1;
        }
        for(int i=start;i<s.length();i++) {
            if(s.charAt(i)>='0' && s.charAt(i)<='9')
                s2=s2+s.charAt(i);
            
        }
        if(s2.length()>0)
        {
            Number=s2;
        }
            
        else
            Number="0";
        return s2;
       
    }//END changeToGood
    
    public void pow(String p1, String p2) {
        p1=changeToGood(p1);
        p2=changeToGood(p2);
        BigInteger obj1=new BigInteger(p1);
        Integer obj2=new Integer(p2);
        BigInteger pow;
        BigInteger i;
        pow=obj1.pow(obj2);
        this.Number=pow.toString();
        //this.Number=pow.toString();
    }
    void pow(BigInt a, BigInt b) {
        pow(a.getNumber(),b.getNumber());
    }

    

    



}
//################END OF CLASS################
